import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-txn-monitor',
  templateUrl: './txn-monitor.component.html',
  styleUrls: ['./txn-monitor.component.scss']
})
export class TxnMonitorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
